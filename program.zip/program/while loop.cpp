#include<stdio.h>
main()
{
	int i=51;
	
	while(i<60)
	{
	printf("THE NUMBER IS : %d\n",i);
	i++;
    }
}
