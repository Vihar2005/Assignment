#include<stdio.h>
main()
{
	int marks = 14;
	
	if(marks>=35)
	{
		printf("pass");
	}
	else
	{
		printf("fail");
	}
}
