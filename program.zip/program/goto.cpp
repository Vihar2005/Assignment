#include<stdio.h>
main()
{
	int sum=0,i=0;
	
	printf("enter number of n : ");
	scanf("%d",&n);
	
	lable;
		++i;
		sum=+i;
	
	if(i<n)
	goto lable;
	printf("sum of %d:%d",n,sum);
	
}
