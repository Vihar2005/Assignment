#include<stdio.h>
main()
{
	int i,a,squre,cube,ans; 
	
	printf("enter of number i : ");
	scanf("%d",&i);
	
	printf("enter of number a : ");
	scanf("%d",&a);
	
	ans=i*a*a;
	
	printf("%d",ans);
}
