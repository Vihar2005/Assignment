#include<stdio.h>
main()
{
	int num1,num2,ans;
	
	printf("enter value of number1 : ");
	scanf("%d",&num1);
	
	printf("enter value of number2 : ");
	scanf("%d",&num2);
	
	ans=num1+num2;
	
	printf("ans=%d",ans);
	
	
}
