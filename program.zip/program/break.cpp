#include<stdio.h>
main()
{
	int i=0;
	while(1)
	{
		i=i+1
		printf("value of i is %d\n",i);
		if(i>5)
		{
			break;
		}
	}
}
