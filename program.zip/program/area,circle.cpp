#include<stdio.h>
main()
{
	float pi=3.14,r,ans;
	
	printf("enter value of r :");
	scanf("%d",&r);
	
	ans=pi*r*r;
	
	printf("%0.2f",ans);
	
}
