#include<stdio.h>
main()
{
	int a[5],i;
	
	for(i=1;i<=5;i++)
	{
		printf("\n%u",&a[i]);
		
	}
}
