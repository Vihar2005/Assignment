#include<stdio.h>
main()
{
	int a,b,ans;
	
	printf("enter value a : ");
	scanf("%d",&a);
	
	printf("enter value b : ");
	scanf("%d",&b);
	
	ans=a*b/2;
	
	printf("ans=%d",ans);
	
} 
