#include<stdio.h>
main()
{
	int dob,age;
	char name,address;
	
	printf("enter nume : ");
	scanf("%c",&name);
	
	fflush(stdin);
	
	printf("enter dob : ");
	scanf("%d",&dob);
	fflush(stdin);
	
	printf("enter age : ");
	scanf("%d",&age);
	
	fflush(stdin);
	
	printf("enter address : ");
	scanf("%c",&address);
	
}
