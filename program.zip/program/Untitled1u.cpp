#include<stdio.h>
main()
{
	int a[]{15,21,14,25,20},i;
	
	for(i=0;i<5;i++)
	{
		printf("\n%d=%d",i+1,a[i]);
	}
}
