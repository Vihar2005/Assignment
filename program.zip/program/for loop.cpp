#include<stdio.h>
main()
{
	int i;
	
	for(i=1;i<11;i++)
	{
	printf("THE NUMBER IS : %d\n",i);
	
    }
}
