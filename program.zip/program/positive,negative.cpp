#include<stdio.h>
main()
{
	int n;
	
	printf("enter value : ");
	scanf("%d",&n);
	if(n<50)
	{
		printf("negetive");
	}
	else
	{
		printf("positive");
	}
}
